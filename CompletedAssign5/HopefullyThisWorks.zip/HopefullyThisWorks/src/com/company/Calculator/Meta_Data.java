package com.company.Calculator;

public class Meta_Data {

    public String state;
    public double salesTax;
}
