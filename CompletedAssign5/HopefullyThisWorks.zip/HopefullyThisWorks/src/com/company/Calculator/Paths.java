package com.company.Calculator;

public class Paths {

    private String filepath = "C:\\Users\\Avaree\\Desktop\\School\\Spring2018\\SoftwareTesting\\Assignment5\\src\\SalesTax.xls";

    public String get_excel_data(){return filepath;}
}
